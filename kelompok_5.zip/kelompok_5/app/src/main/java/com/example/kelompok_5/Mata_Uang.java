package com.example.kelompok_5;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import static com.example.kelompok_5.R.layout.activity_mata_uang;

public class Mata_Uang extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(activity_mata_uang);
    }
}